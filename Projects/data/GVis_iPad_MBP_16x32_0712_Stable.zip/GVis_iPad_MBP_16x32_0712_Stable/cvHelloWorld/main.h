/*****************************************************
 * Copyright (c) 2013, Regents of National Taiwan University
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *        notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the National Taiwan University nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ****************************************************/
//GaussSenseV1 32x16 Terminal: main.h

#ifndef main_h
#define main_h

#define BOARD_NUM 1
#define X_NUM 32
#define Y_NUM 16
#define SEN_NUM X_NUM*Y_NUM
#define SAMPLE_RATE 20

#define THLD_RADIUS 0
#define THLD_LINK 3*SAMPLE_RATE

#include <iostream>
#include <stdio.h>
#include "vector"
#include "math.h"
#include "HID.h"
#include "OscOutboundPacketStream.h"
#include "UdpSocket.h"
#include "opencv2/opencv.hpp"

#include "BicubicInterpolator.h"
#include "BiLinearInterpolator.h"
#include "gBit.h"

using namespace std;
using namespace cv;

//OSC related 
#define OSC_SEND
#define ADDRESS "oscHost.local"
#define PORT 12345
#define OSC_COLUMNS 32
#define OSC_BUFFER_SIZE 8192
#define SEND_BUF_LEN 64
#define RECV_BUF_LEN 64
UdpTransmitSocket transmitSocket(IpEndpointName( ADDRESS, PORT ) );
char buffer[OSC_BUFFER_SIZE];
osc::OutboundPacketStream p( buffer, OSC_BUFFER_SIZE );
void sendOSC();

//USB (HID) related 
unsigned char sBuff[BOARD_NUM][SEND_BUF_LEN];
unsigned char rBuff[BOARD_NUM][RECV_BUF_LEN];
int num[BOARD_NUM];
int devNum;

//Sensor related
int sensorRcv[SEN_NUM];
int sensorVal[X_NUM][Y_NUM];
int sensorZero[X_NUM][Y_NUM];
float sampleVal[SAMPLE_RATE*X_NUM][SAMPLE_RATE*Y_NUM];
BicubicInterpolator bcp;
BiLinearInterpolator blp;

void initVals();
void upSampling(int ratio);
void recordSampleData(bool isBoundary, int ratio, int i, int j);
bool bCalibed = false;
bool bFlipSide = false;
int rawVal = 0, cVal = 0;

//Vis
# define cR 2
# define THLD_TILTRATIO 1.1
# define CONTOUR_RESOLUTION 1
# define TOKEN_NUM 100
int THLD_TILT = 96, THLD_HOVER = 40;
int isHoverableN, isTiltableN;
int isHoverableS, isTiltableS;

int tAngle;
float tPitch;

bool showRaw = true;
bool showContour = true;
bool showInfo = true;
bool showBox = false;
bool showNF = true, showSF = true;
bool showP = true;

bool isRot[TOKEN_NUM];
bool isNPolar[TOKEN_NUM];
bool isN;

vector<cv::Point> points;
vector<GTag5D> oscData;
Mat_<float>::iterator it;
Mat_<float>::iterator end;

void drawCross(Mat m, Point2d p, Scalar c, int len, bool type);
double find_eu_distance(const CvPoint& point_one, const CvPoint& point_two);
void setPointColor(Mat_<Vec3b> _I, int x, int y, float sampleV, bool bClipped);
void visContours(Mat fieldImg, vector< vector<Point> > contoursN, vector< vector<Point> >contoursS, Scalar OuterContourColorN, Scalar OuterContourColorS, int strW);
void showResults(Mat resultImg, Mat fieldImg);
void disableSensor(int start_row, int start_col, int end_row, int end_col);

//Variables
Point2f pHiN(-1,-1),    pHiS(-1,-1);
Point2f pHiN_F(-1,-1),  pHiS_F(-1,-1);
Point2f pLoN(-1,-1),    pLoS(-1,-1);
Point2f pLoN_F(-1,-1),  pLoS_F(-1,-1);
Point2f pN(-1,-1),      pS(-1,-1);
Point2f pN_F(-1,-1),    pS_F(-1,-1);
Point2f pCenter(-1,-1);
Point2f pMax(-1,-1), pMin(-1,-1);
float maxM = -1, minM = 2000;

Point2f finalCentroidN[TOKEN_NUM];
Point2f finalCentroidS[TOKEN_NUM];

double sideA_H_N[TOKEN_NUM], sideB_H_N[TOKEN_NUM];
double sideA_T_N[TOKEN_NUM], sideB_T_N[TOKEN_NUM];
double sideA_H_S[TOKEN_NUM], sideB_H_S[TOKEN_NUM];
double sideA_T_S[TOKEN_NUM], sideB_T_S[TOKEN_NUM];
double ABRatio_H_N[TOKEN_NUM], ABRatio_T_N[TOKEN_NUM];
double ABRatio_H_S[TOKEN_NUM], ABRatio_T_S[TOKEN_NUM];

float mValN[TOKEN_NUM], mValS[TOKEN_NUM];

Point2f hoverBoxN_[TOKEN_NUM][4];
//Point2f hoverBoxN_MidPoints[TOKEN_NUM][4];
Point2f hoverBoxN_Centroid[TOKEN_NUM];
Point2f hoverBoxS_[TOKEN_NUM][4];
//Point2f hoverBoxS_MidPoints[TOKEN_NUM][4];
Point2f hoverBoxS_Centroid[TOKEN_NUM];
float hoverBoxN_Radius[TOKEN_NUM];
float hoverBoxS_Radius[TOKEN_NUM];

Point2f tiltBoxN_[TOKEN_NUM][4];
Point2f tiltBoxN_MidPoints[TOKEN_NUM][4];
Point2f tiltBoxN_Centroid[TOKEN_NUM];
Point2f tiltBoxS_[TOKEN_NUM][4];
Point2f tiltBoxS_MidPoints[TOKEN_NUM][4];
Point2f tiltBoxS_Centroid[TOKEN_NUM];
float tiltBoxN_Radius[TOKEN_NUM];
float tiltBoxS_Radius[TOKEN_NUM];

int rotationPairN[TOKEN_NUM];
int rotationPairS[TOKEN_NUM];
int hoverTiltPairN[TOKEN_NUM];
int hoverTiltPairS[TOKEN_NUM];

#endif
